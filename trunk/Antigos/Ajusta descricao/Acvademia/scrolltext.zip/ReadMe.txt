This component is published as freeware. 

TScrollText (Version 1.0) allows lines of text to be scrolled horizontally or vertically. It facilitates, amoung other things, the text display features to be changed, such as alignment, font and style(lowered, raised, shaddow or normal).

I have developed this component using Delphi 2. Although I have not tried running it on Delphi 1, the component should compile OK if you remove the 32-bit .DCR file but the demo program includes some Delphi 2 only components.

If you have any comments please send me a message.

Darryl West (dwest@dot.net.au)
Sydney, Australia 
15 October, 1996