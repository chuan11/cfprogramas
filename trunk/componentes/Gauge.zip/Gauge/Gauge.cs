using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace ComponentGauge
{
	/// <summary>
	/// Summary description for Gauge.
	/// </summary>
	public class Gauge : System.Windows.Forms.UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private int valor = 0;
		private Color inicial = Color.FromArgb(225, 154, 27);
		private Color final = Color.FromArgb(246, 213, 120);
		private Color borda = Color.Orange;

		public Gauge()
		{
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Gauge
			// 
			this.BackColor = System.Drawing.SystemColors.Control;
			this.Name = "Gauge";
			this.Size = new System.Drawing.Size(176, 15);
			this.Resize += new System.EventHandler(this.Gauge_Resize);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Gauge_Paint);
		}
		#endregion

		private int calculaPercentual()
		{
			int x, z;
			z = base.Width * Valor;
			x = z / 100;
			return x;
		}

		private Brush GetFundoGradiente()
		{
			RectangleF recF = new RectangleF((float) 0f, 0f, calculaPercentual(), (float) base.Size.Height);
			LinearGradientBrush gradiente = new LinearGradientBrush(recF, Inicial, Final, (float) 270f);
			float[] Intensidades = {0.0f, 0.3f, 1.0f};
			float[] Posicoes   = {0.0f, 0.2f, 1.0f};
			Blend blend = new Blend();
			blend.Factors = Intensidades;
			blend.Positions = Posicoes;
			gradiente.Blend = blend;
			return gradiente;
		}

		private void Gauge_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics graphics1 = e.Graphics;
			Pen pen1 = new Pen(Borda, 2f);
			graphics1.DrawRectangle(pen1,(float) 0f, 0f, base.Width, (float) base.Size.Height);
			if (Valor > 0)
			{
				graphics1.FillRectangle(this.GetFundoGradiente(), (float) 0f, 0f, calculaPercentual(), (float) base.Size.Height);
			}
			graphics1.DrawString(Convert.ToString(Valor) + "%", this.Font, new SolidBrush(this.ForeColor),(float) base.Size.Width/2 - 9f, (float) base.Size.Height/2 - 7f);
		}

		private void Gauge_Resize(object sender, System.EventArgs e)
		{
			this.Refresh();
		}

		public int Valor
		{
			get
			{
				return valor;
			}
			set
			{
				if (value < 0 || value > 100)
				{
					MessageBox.Show("Valor Inv�lido.", "Gauge", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				else
				{
					valor = value;
					this.Refresh();
				}
			}
		}
		
		public Color Inicial
		{
			get
			{
				return inicial;
			}
			set
			{
				inicial = value;
				this.Refresh();
			}
		}

		public Color Final
		{
			get
			{
				return final;
			}
			set
			{
				final = value;
				this.Refresh();
			}
		}

		public Color Borda
		{
			get
			{
				return borda;
			}
			set
			{
				borda = value;
				this.Refresh();
			}
		}

		[Browsable(false)]
		public override Image BackgroundImage
		{
			get
			{
				return null;
			}
		}
	}
}
